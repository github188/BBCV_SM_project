#!/bin/bash

chmod a+x lib_bbcv/*
sudo cp -d lib_bbcv/* /usr/local/lib/

chmod a+x lib_ffmpeg/*
sudo cp -d lib_ffmpeg/* /usr/local/lib/

chmod a+x lib_ipp/*
sudo cp -d lib_ipp/* /usr/local/lib/

chmod a+x bin/*
sudo cp -d bin/* /usr/local/bin/
sudo cp -d bin/Xvnc /usr/local/bin/bvbcs

sudo ldconfig
