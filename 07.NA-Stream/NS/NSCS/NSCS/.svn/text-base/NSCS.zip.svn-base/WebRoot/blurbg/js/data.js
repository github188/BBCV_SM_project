﻿/**
 * Created by lx on 14-4-18.
 */
var info={
		'length':3,
		'movie0':{
	        id:"gyc",
			name:"关云长",
			movieintro:"刘备家眷被困曹营，关云长为存忠义甘作俘虏，被迫为曹军上阵。一场大战，关云长单人匹马斩杀敌方大将，技惊四座，而深受曹操赏识。可是关云长却“身在曹营心在汉”。对曹操所有礼遇均做出婉辞。后曹操查知关云长心仪刘备未过门的新妾“绮兰”，只因一个“义”字而未敢表白。曹操暗施狡计，送上催情毒酒，欲陷关羽于不义！关羽悬崖勒马，从而带着对此充满恨意的绮兰杀出曹营。一路上，关羽连毙曹操大将，但是，威武的背后，饱受感情折磨。曹操为稳定军心，而亲自出征，誓要将关羽擒拿！几经艰苦，终于来到黄河渡口，平静河边已布下曹军亲兵的十面埋伏！生死关头，死敌曹操竟一再以礼相待，忠义如关羽亦不禁动摇！身旁的绮兰苦苦相谏，关云长必须在“情”、“义”之间作出抉择。",
			videosrc:"video/gyc.mp4",
			director:"麦兆辉 / 庄文强",
			actor:" 甄子丹 / 姜文 ",
			type:"剧情 / 动作 ",
			ondata:"2011-04-26",
			rstp:"rtsp://192.168.100.11:8845/yjy_ipqam/8081/gyc.ts",
			poster:"images/movie/gyc.jpg",
			sliderposter:"images/gyc-big.jpg",
			area:"中国大陆",
			star:"5.6",
			other:""
		},
		'movie1':{
			id:"aqgy",
			name:"爱情公寓",
			movieintro:"展博和宛瑜来到了电影院,没有订到包场的展博放弃了求婚计划,看电影时呼呼睡着.片尾时,电影院放起了求婚音乐,宛瑜误以为是展博安排的,一个劲的说不行.这让展博大吃一惊.电影散场后,展博带宛瑜吃宵夜,但由于忘记带钱包而被老板扣押.一菲和美嘉在给他们送钱的路上不幸迷了路.展博的求婚戒指无奈被当做了抵押物扣在餐厅,两人才得以脱身.回到家的展博终于鼓起勇气向宛瑜表白。",
			videosrc:"video/aqgy.mp4",
			director:"韦正",
			actor:" 娄艺潇 / 陈赫",
			type:"喜剧 / 爱情",
			ondata:"2014-01-17",
			rstp:"rtsp://192.168.100.11:8845/yjy_ipqam/8080/dsj.ts",
			poster:"images/movie/aqgy.jpg",
			sliderposter:"images/aqgy-big.jpeg",
			area:"中国大陆",
			star:"5.6",
			other:""
		},
		'movie2':{
			id:"ypzjs",
			name:"营盘镇警事",
			movieintro:"上河村几十号人正在捣毁下河村的“水口子”，下河村村民强烈反抗，两村青壮劳力操着农具准备大干一场。党育火速前往事发地点，凭借20多年辛勤工作留在百姓心中的信誉，终于让两村百姓同意和解。县局周局长大为光火，要求党育10天破案。党育受命后又软磨硬泡向局长要人，结果局长给他分了一个“中看不中用的花瓶”警花何雨桐。",
			videosrc:"video/ypzjs.mp4",
			director:"马进",
			actor:" 张嘉译 / 丁海峰  ",
			type:"剧情 / 传记 / 犯罪",
			ondata:"2012-09",
			rstp:"rtsp://192.168.100.11:8845/yjy_ipqam/8081/ypzjs.ts",
			poster:"images/movie/ypzjs.jpg",
			sliderposter:"images/ypzjs-big.jpg",
			area:"中国大陆",
			star:"5.6",
			other:""
		}
    }
	
