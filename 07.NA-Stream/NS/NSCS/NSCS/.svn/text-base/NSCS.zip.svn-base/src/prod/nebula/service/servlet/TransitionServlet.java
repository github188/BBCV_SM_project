/**  
 * 类名称：TransitionServlet 
 * 类描述： 
 * 创建人：PengFei   
 * 创建时间：2014-10-8 下午08:10:37 
 */
package prod.nebula.service.servlet;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import prod.nebula.service.thread.DeletFileDataThread;

/**
 * 类名称：TransitionServlet 类描述： 创建人：PengFei 创建时间：2014-10-8 下午08:10:37 备注：
 * 
 * @version
 * 
 */
public class TransitionServlet extends HttpServlet {
	private static final Logger logger = LoggerFactory
			.getLogger(TransitionServlet.class);
	/**
	 * @Fields serialVersionUID : TODO(用一句话描述这个变量表示什么)
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Constructor of the object.
	 */
	public TransitionServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		System.out.println("destroy()");
	}

	/**
	 * The doGet method of the servlet. <br>
	 * 
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request
	 *            the request send by the client to the server
	 * @param response
	 *            the response send by the server to the client
	 * @throws ServletException
	 *             if an error occurred
	 * @throws IOException
	 *             if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		this.doPost(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 * 
	 * This method is called when a form has its tag value method equals to
	 * post.
	 * 
	 * @param request
	 *            the request send by the client to the server
	 * @param response
	 *            the response send by the server to the client
	 * @throws ServletException
	 *             if an error occurred
	 * @throws IOException
	 *             if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		PrintWriter out = response.getWriter();

		String thisState = request.getParameter("thisState");
		String read = request.getParameter("method");
		// System.out.println(streamid);

		if ("2".equals(read)) {

			logger.info("subinter1 页面查询！");

			String path = TransitionServlet.class.getResource("").getPath();
			File f = new File(path + "state.txt");
		    if (!f.exists()) {   
	            f.createNewFile();   
	        } 
			FileReader fr = new FileReader(f);

			BufferedReader br = new BufferedReader(fr);
			String s;
			StringBuffer sb = new StringBuffer();
			while ((s = br.readLine()) != null) {
				// System.out.println(s);
				sb.append(s);
			}
			logger.info(path + "state.txt 中内容是：" + sb.toString() + "长度是："
					+ sb.toString().length());

			if (sb.toString().length() > 0) {
				logger.info("servlet将返回 success ");
				out.println("success");
				out.close();
			}

		}

		if ("3".equals(read)) {
			logger.info("清空文件内容");

			String path = TransitionServlet.class.getResource("").getPath();
			File f = new File(path + "state.txt");
		    if (!f.exists()) {   
	            f.createNewFile();   
	        } 
			FileWriter fw = new FileWriter(f);
			// System.out.println(path);

			if (f.exists()) {

				logger.info("要清空的文件存在！写\"\"");
				fw.write("");
				FileReader fr = new FileReader(f);

				BufferedReader br = new BufferedReader(fr);
				String s;
				StringBuffer sb = new StringBuffer();
				while ((s = br.readLine()) != null) {
					// System.out.println(s);
					sb.append(s);
				}
				logger.info("清空后文件 内容是：" + sb.toString() + "长度是："
						+ sb.toString().length());
				fw.flush();
				fw.close();

				out.println("success");
				out.close();
			} else {
				logger.info("要清空的文件不存在！");

			}

		}

		if ("1".equals(thisState)) {
			logger.info("用户点击了播放按钮  将向");
			String path = TransitionServlet.class.getResource("").getPath();
			File f = new File(path + "state.txt");
		    if (!f.exists()) {   
	            f.createNewFile();   
	        } 
			FileWriter fw = new FileWriter(f);
			// System.out.println(path);

			if (f.exists()) {

				fw.write("1");
				logger.info(path + "state.txt 中内容 写 1");
				fw.flush();
				fw.close();

				DeletFileDataThread df = new DeletFileDataThread();
				new Thread(df).start();

			} else {
				logger.info("文件不存在！");

			}
			// out.println("success");
			out.close();

		}

	}

}
