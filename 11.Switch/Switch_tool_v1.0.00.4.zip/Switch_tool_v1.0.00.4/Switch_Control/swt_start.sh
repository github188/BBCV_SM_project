#�� /bin/bash
sudo killall Switch_tool
nohup ./Switch_tool > out.log 2>&1 &
#nohup ./Switch_tool > /dev/null 2>&1 & 
#echo "ok"
