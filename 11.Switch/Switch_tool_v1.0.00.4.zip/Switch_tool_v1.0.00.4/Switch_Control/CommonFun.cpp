#include "CommonFun.h"
#include <string.h>

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <sys/types.h>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <string>


/*!
* \brief  ���ַ����е�һ��������һ���滻,ע��strbuf�������㹻�Ŀռ����洢�滻��Ĵ�,��������ڴ����
*
* \param
*      strbuf : �ַ���(����/���)
*      src_str : Ŀ���ַ��Ӵ�
*      desc_str     : �滻����Ӵ�
* \return
*      �滻����ַ���
*
*/
char * replace(char *strbuf, const char *src_str, const char *desc_str)
{

	char *pos, *pos1;

	if (strbuf == NULL || src_str == NULL || desc_str == NULL) return strbuf;

	if (strlen(src_str) == 0) return strbuf;
	int ilen = strlen(strbuf);
	char *org = new char[ilen + 1];

	strcpy(org, strbuf);
	pos = org;
	strbuf[0] = 0;
	while (1)
	{
		pos1 = strstr(pos, src_str);
		if (pos1 == NULL)
			break;
		*pos1 = '\0';
		strcat(strbuf,  pos);
		strcat(strbuf, desc_str);
		pos = pos1 + strlen(src_str);
	}
	strcat(strbuf,  pos);
	delete org;
	return strbuf;
}



int applyforUDPPort(char *ip,int *port)
{
	struct sockaddr_in bindaddr;
	socklen_t len;
	
	struct sockaddr_in servaddr;
	memset(&servaddr,0, sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = inet_addr(ip);
	servaddr.sin_port = htons(*port);

	printf("%s:%d\n",ip,*port);
		
	int test_socket = socket(AF_INET, SOCK_DGRAM, 0);
	if(test_socket == -1)
		return -1;
	
	int optval = 1;
	if ((setsockopt(test_socket,SOL_SOCKET,SO_REUSEADDR,&optval,sizeof(int))) == -1)
	{
		close(test_socket);
		return -2;
	}

	if(bind(test_socket, (struct sockaddr *)&servaddr, sizeof(servaddr)) == -1)
	{
		close(test_socket);
		return -3;
	}
	
	if( 0 == getsockname( test_socket, ( struct sockaddr* )&bindaddr, &len ))
	{
		printf("%s:%d\n",inet_ntoa(bindaddr.sin_addr),ntohs(bindaddr.sin_port));
		
	//	*port = ntohs(bindaddr.sin_port);
	}
	else
	{
		close(test_socket);
		return -4;
	}
	
	close(test_socket);
	return 0;
}

bool get_ClientPeer(int sockid,std::string &host,int &port)
{
    struct sockaddr sockAddr;
		memset(&sockAddr, 0, sizeof(sockAddr));
		socklen_t i_len = sizeof(sockAddr);
	
    if(getpeername(sockid,&sockAddr, &i_len)<0)
     return false;
    
    struct sockaddr_in *addr= (sockaddr_in *)&sockAddr;
    host=inet_ntoa(addr->sin_addr);
    port=ntohs(addr->sin_port);	
    return true;
}


int FindDataFromString(const char* strinput,char* strData1,char* strData2)
{
	if(strData1 == NULL || strData2 == NULL || strinput == NULL)
		return -1;
	
	std::string strInputurl;
	strInputurl.assign(strinput);

	int size_type0 = strInputurl.find("//");
	int size_type1 = strInputurl.find(":");
	//printf("  %d  %d \n",size_type0,size_type1);

	std::string tmp = strInputurl.substr(size_type0+2);  //size_type1
	int size_type2 = tmp.find(":");
//	printf("--%d %s \n",size_type2,tmp.substr(0,size_type2).c_str());
	sprintf(strData1,"%s",tmp.substr(0,size_type2).c_str());
	std::string tmp1 = tmp.substr(size_type2+1);
	sprintf(strData2,"%s",tmp1.c_str());

//	printf("---data1=%s data2=%s \n",strData1,strData2);

	return 0;
}


