#�� /bin/bash
sudo killall Switch_tool

#echo "ok"
